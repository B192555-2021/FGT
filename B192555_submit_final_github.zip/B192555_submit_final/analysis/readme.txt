To run the code, 
download my code and the B192555_raw.tar into the same directory, 
check the needed package installed, 
then use 
R --slave --no-save --args . B192555_raw.tar<B192555.R
args[1] is the directory of the file
args[2] is the file name

B192555_raw.tar contains:
all cel files
and the targetsraw.txt which is also needed to run the code

the targetsraw.txt is also provided in here in case that cannot use my B192555_raw.tar file