# this is B192555's modification of FGT code for Microarray Analysis Workflow 


##Load the required libraries & load the files for the workflow
library(limma)
library(affy)
library(annotate)
library(mouse4302.db)# load chip-specific annotation
library(scatterplot3d)
library(affyPLM) 
library(affyQCReport)
library(simpleaffy)
# it can generate better color for figure
library(RColorBrewer)
#BiocManager::install("AffyRNADegradation")
library(AffyRNADegradation)
#BiocManager::install("ggfortify")
library(ggfortify) #for pca plot

#test if user give the right value
tryCatch({
  args <- commandArgs(TRUE)
  exists(args[1])
  exists(args[2])
}, warning = function(w){
  print("Warning for your input of dir and file")
}, error = function(e){
  print("Error for your input of dir and file")
  quit()
},finally = {
  print(paste("Your input dir name: ",args[1]," file name: ",args[2]))
})

#test if the dir path exist
if (dir.exists(args[1])==FALSE){
  print("dir not exist")
  quit() }else{
    setwd(args[1])
    print(paste("Your working dir will be ",getwd()))
  }

#test if the file exist
if (file.exists(args[2])==FALSE){
  print("file not exist")
  quit() }else{
    print(paste("Your file will be ",args[2])) 
  }

# unzip the tar sep="" to paste without space
workdir <- args[1]
tarfile <- args[2] #"B192555_raw.tar"
rawdir <- "B192555_raw"

#unzip the tar file
system(paste("tar -xvf ",tarfile))
setwd(paste("./",rawdir,sep=""))
getwd()

###load all CEL files in the R working directory, gz file can load without unzip
GSEdata <- ReadAffy()
#modify the samplename, here the orginal name is eg GSM289160.CEL.gz, so I split by ".", fixed=TRUE to not use regular expression 
rename <- sampleNames(GSEdata)
for (i in 1:length(rename)){
  sampleNames(GSEdata)[i] <- strsplit(rename,".",fixed=TRUE)[[i]][1]
}
 
###data QC
#grey-scale map https://blog.csdn.net/tommyhechina/article/details/80335879
for (i in 1:length(sampleNames(GSEdata))){
  image_name = paste("greyimage",sampleNames(GSEdata)[i],".jpg",sep="")
  jpeg(image_name)
  image(GSEdata[,i])
  dev.off()
}

#histogram with rainbow color
png(file="QChistogram.png", bg="transparent")
rainbowcols <-rainbow(length(sampleNames(GSEdata)))
hist(GSEdata, main="Histogram", col=rainbowcols)
legend("topright", legend = sampleNames(GSEdata), lty = 1, col = rainbowcols, box.col = "transparent",xpd = TRUE)
dev.off()

#Boxplot with different colour per sample group
colours <- c(rep("yellow",3),rep("red",3))
png(file="QCboxplot.png", bg="transparent")
par(pin = c(5,4)) #this helps to display the x-labels in complete
boxplot(GSEdata, col=colours, las=2, horizontal = FALSE, ylab="log intensity")
dev.off()

#save the table for absent and present, quote=FALSE is to delete the quote for the row name
calls <- exprs(mas5calls(GSEdata))
absent <- colSums(calls == 'A')
present <-colSums(calls == 'P')
write.table(cbind(present,absent),file = "./absent_present.csv", quote = FALSE)

#Execute the Quality Control
qcdata = qc(GSEdata)
png(file="QCsummary.png", bg="transparent")
plot(qcdata)
dev.off()

#check the RNA degradation by plot https://zhuanlan.zhihu.com/p/137852795
RNAdeg <- AffyRNAdeg(GSEdata)
summaryAffyRNAdeg(RNAdeg)
rainbowcols <-rainbow(length(sampleNames(GSEdata)))
png(file="QC_RNA_degradation.png", bg="transparent")
plotAffyRNAdeg(RNAdeg, cols = rainbowcols)
legend("topleft", legend = sampleNames(GSEdata), lty = 1, col = rainbowcols, box.col = "transparent",xpd = TRUE)
dev.off()

#fit the basic probe-level model  https://zhuanlan.zhihu.com/p/137852795
Pset <- fitPLM(GSEdata)

#RLE plot (Relative Log Expression )
png(file="QC_RLE.png", bg="transparent")
par(pin = c(5,4)) #this helps to display the x-labels in complete
RLE(Pset, col=rainbowcols, las=2, horizontal = FALSE, main="RLE")
dev.off()

#NUSE plot (Normalized Unscaled Standard Errors )
png(file="QC_NUSE.png", bg="transparent")
par(pin = c(5,4)) #this helps to display the x-labels in complete
NUSE(Pset, col=rainbowcols, las=2, horizontal = FALSE, main="NUSE")
dev.off()


### Normalise the data using RMA

# https://www.rdocumentation.org/packages/affy/versions/1.50.0/topics/rma
# rma(object, subset=NULL, verbose=TRUE, destructive=TRUE, normalize=TRUE, background=TRUE, bgversion=2, ...)
eset <- rma(GSEdata)
#obtain the expression values
eset_values <- exprs(eset)

# Boxplot to observe the results of normalisation
png(file="RMA_boxplot.png", bg="transparent")
par(pin = c(5,4)) #this helps to display the x-labels in complete
boxplot(eset, col=colours, las=2, horizontal = FALSE, ylab="log intensity", main="Boxplot of Normalised Data")
dev.off()

#histogram to observe the results of normalisation
png(file="RMA_histogram.png", bg="transparent")
par(pin = c(5,4)) #this helps to display the x-labels in complete
hist(eset, main="Histogram of Normalised Data", col=rainbowcols)
legend("topright", legend = sampleNames(GSEdata), lty = 1, col = rainbowcols, box.col = "transparent",xpd = TRUE)
dev.off()

# MA plot parameters: https://rdrr.io/bioc/affy/man/mva.pairs.html
png(file="RMA_MA.png", bg="transparent")
mva.pairs(eset_values, main="MVA plot of normalised data", cex=2)
dev.off()
# The same plot for the non-normalised raw data
#png(file="RMA_MA_raw.png", bg="transparent")
#mva.pairs(pm(GSEdata), main="MVA plot of raw data", cex=2)
#dev.off()


### Basic data analysis

# targetsraw.txt is provided in my uploaded tar file
adf<-read.AnnotatedDataFrame(file="targetsraw.txt",sep="\t", header=TRUE,row.names=1,as.is=TRUE)
colnames(eset_values) <- rownames(pData(adf))

# Plot heatmap
png(file="ANALYSIS_Heatmap.png", bg="transparent")
heatmap(eset_values[1:100,],main = "Heatmap") #plot all genes is too slow
dev.off()

# Performs hierarchical clustering
hc<-hclust(as.dist(1-cor(eset_values, method="pearson")), method="average")
png(file="ANALYSIS_cluster.png", bg="transparent")
plot(hc)
dev.off()


### Perform PCA

pca <- prcomp(t(eset_values), scale=T)
# Plot the PCA results https://cran.r-project.org/web/packages/ggfortify/vignettes/plot_pca.html
png(file="PCA1.png", bg="transparent")
autoplot(pca, colour=rainbow(length(sampleNames(GSEdata)),start=0,end=0.6), label = TRUE, label.size = 6)
dev.off()
#Plot the PCA in 3dplot sample_name
png(file="PCA_3D.png", bg="transparent")
s3d<-scatterplot3d(pca$x[,1:3], pch=19, color=rainbow(length(sampleNames(GSEdata)),start=0,end=0.6))
s3d.coords <- s3d$xyz.convert(pca$x[,1:3])
text(s3d.coords$x, s3d.coords$y, labels = colnames(eset_values),pos = 3,offset = 0.5)
dev.off()


### Annotation

#packages in the annotation package
ls("package:mouse4302.db")
#build an annotation table
ID <- featureNames(eset)
Symbol <- getSYMBOL(ID, "mouse4302.db")
Name <- as.character(lookUp(ID, "mouse4302.db", "GENENAME"))
tmp <- data.frame(ID=ID, Symbol=Symbol, Name=Name, stringsAsFactors=F)
tmp[tmp=="NA"] <- NA #fix padding with NA characters 
#assign as feature data of the current Eset
fData(eset) <- tmp


### Perform fold filtering

#obtaining a matrix of expression values
exprsvals <- exprs(eset)
#To convert RMA outputs log2 data from log…
exprsvals_linear <-2^exprsvals
#obtain a vector of ProbeIDs
probesets <- probeNames(GSEdata)

#Calculate the means in real not log level
ctrl.mean <- apply(exprsvals_linear[,c("GSM289098", "GSM289160","GSM289161")],1,mean)
VhlhKO.mean <- apply(exprsvals_linear[,c("GSM289162", "GSM289163","GSM289164")],1,mean)

#calculate some fold changes for both c/t t/c
VhlhKO_fold <- VhlhKO.mean/ctrl.mean
ctrl_fold <- ctrl.mean/VhlhKO.mean
#build a summary table to hold all the data
sort_VhlhKO_fold <- cbind(sort(VhlhKO_fold, decreasing = TRUE))
sort_ctrl_fold <- cbind(sort(ctrl_fold, decreasing = TRUE))

#set col name
colnames(sort_VhlhKO_fold) <- "fold_change(treat/ctrl)"
colnames(sort_ctrl_fold) <- "fold_change(ctrl/treat)"

#write the table of means as an output
write.table(sort_VhlhKO_fold, file="fold_changes_TC.txt", quote=F, sep="\t",col.names=NA)
write.table(sort_ctrl_fold, file="fold_changes_CT.txt", quote=F, sep="\t",col.names=NA)

#calculate expression level
expression <- exprs(mas5calls(GSEdata))
#find expression_data of top10 fold change
#here %in% to find the 10 gene names row in expression https://blog.csdn.net/weixin_40640700/article/details/123233537
expression_VhlhKO_fold <- expression[which(rownames(expression)%in%rownames(sort_VhlhKO_fold)[1:10]),]
expression_ctrl_fold <- expression[which(rownames(expression)%in%rownames(sort_ctrl_fold)[1:10]),]
#write the table for P/M/A data of the top 10
write.table(expression_VhlhKO_fold, file="expression_data_top10_TC_by_fold_changes.txt", quote=F, sep="\t")
write.table(expression_ctrl_fold, file="expression_data_top10_CT_by_fold_changes.txt", quote=F, sep="\t")


##also calculate logFC
log_fold <- log2(VhlhKO_fold)
# sort logFC by absolute
log_fold2 <- cbind(log_fold)
sort_log_fold <- log_fold2[order(abs(log_fold2[,1]), decreasing = TRUE),]
sort_log_fold <-cbind(sort_log_fold)
colnames(sort_log_fold) <- "log_fold_change"
#write the table of means as an output
write.table(sort_log_fold, file="fold_changes_log.txt", quote=F, sep="\t", col.names=NA)
#write the table for P/M/A data of the top 10
expression_log_fold <- expression[which(rownames(expression)%in%rownames(sort_log_fold)[1:10]),]
write.table(expression_log_fold, file="expression_data_top10_log_by_fold_changes.txt", quote=F, sep="\t")


### Statistical analysis using Limma

# Rename the samples
sampleNames(eset) <- rownames(pData(adf))

#Build the design matrix
design <- model.matrix(~-1+factor(c(1,1,1,2,2,2)))
colnames(design) <- c("Ctrl","VhIhKO")
#Check it makes sense
sampleNames(eset)
#output the design matrix
design

#This instructs Limma which comparisons to make
contrastmatrix <- makeContrasts(VhIhKO-Ctrl, levels=design)

# fit the model and make the contrasts
fit <- lmFit(eset, design)
fit2 <- contrasts.fit(fit, contrastmatrix)
fit2 <- eBayes(fit2)

#get the top 10 results sorted by logFC p or Bh
limma_top10_logFC <- topTable(fit2,coef=1,adjust="fdr", sort.by="logFC", number=10)
limma_top10_P <- topTable(fit2,coef=1,adjust="fdr", sort.by="P", number=10)
limma_top10_BH <- topTable(fit2,coef=1,adjust="fdr", sort.by="P", number=10)
#get the all results
allresults <-topTable(fit2,coef=1, adjust="fdr", number=nrow(eset))
#write results in table
write.table(allresults,"limma_results.txt")
write.table(limma_top10_logFC,"limma_top10_logFC.txt", quote=F, sep="\t")
write.table(limma_top10_P,"limma_top10_P.txt", quote=F, sep="\t")
write.table(limma_top10_BH,"limma_top10_BH.txt", quote=F, sep="\t")

#make a venn diagram
clas <- classifyTestsF(fit2)
png(file="Limma_venn.png", bg="transparent")
vennDiagram(clas)
dev.off()

#p-value histogram https://zhuanlan.zhihu.com/p/439169491
png(file="Limma_pvalue_hist.png", bg="transparent")
par(pin = c(5,4))
hist(allresults$P.Value, col=brewer.pal(3, name = "Set2")[1], main="P Value distribution", xlab="p-values" ,ylab="frequency")
dev.off()

###Functional Enrichment analysis
Mm.H <- readRDS("/shared_files/MSigDB/Mm.h.all.v7.1.entrez.rds") 

#Show the annotation keys in this database
keytypes(mouse4302.db) 

## Process annotation for functional enrichment

#Here we select from the annotation a number of keys with the primary key being PROBEID
#####if dplyr package is in library there will be error to use select
res <- AnnotationDbi::select(mouse4302.db, keys=rownames(eset), columns=c("ENTREZID", "ENSEMBL","SYMBOL"), keytype="PROBEID")

#find the index of each row of the expression set in the #annotation object res
idx <- match(rownames(eset), res$PROBEID)
#Use the index to set the phenotypic data in the ExpressionSet
fData(eset) <- res[idx, ]
head(fData(eset), 10)
#Find all rows that don’t have an EntrezID and remove then
eset_t<-eset[is.na(fData(eset)$ENTREZID)==0,]


## Functional Enrichment Analysis

#convert to indexes
H.indices <- ids2indices(Mm.H,fData(eset_t)$ENTREZID)
#Pick the most suitable enrichment analysis tool to find #enrichment signatures in the data and run this tool So:-

#I just run mroast here as an example- justify the selection of this method!

#run mroast
results_mroast <-mroast(eset_t,index=H.indices,design=design,contrast=contrastmatrix[,1],adjust.method = "BH")
write.table(results_mroast,"enrichment_mroast.txt",sep="\t")
#run camera
results_camera <-camera(eset_t,index=H.indices,design=design,contrast=contrastmatrix[,1])
write.table(results_camera,"enrichment_camera.txt",sep="\t")
#run romer
#results_romer <-romer(eset_t,index=H.indices,design=design,contrast=contrastmatrix[,1])
#write.table(results_romer,"enrichment_mroast.txt",sep="\t")


#plot the up/down tendency
camera_length <- length(results_camera[,1])
#save "down" as -1, "up" = 1
updown <- rep(0,each=camera_length)
for (i in 1:camera_length){
  if(results_camera[i,2]=="Down"){
    updown[i] <- c(-1)
  }
  if(results_camera[i,2]=="Up"){
    updown[i] <- c(1)
  }
}
results_camera <- cbind(results_camera, updown)

#choose a p-value threshold to barplot in different colour 
p_cut <- c(0.05)
p_color <- rep("red",each=camera_length)
for (i in 1:camera_length){
  if(results_camera[i,3] >= p_cut){
    p_color[i] <- c("grey")
  }
  if(results_camera[i,3] < p_cut){
    p_color[i] <- c("#FF9999") # #FF9999 is a light red color  
  }
}

#save png
png(file="enrichment_plot.png", bg="transparent")
par(mar = c(17, 2, 4, 2)+1, yaxt="n") #set this because the xlab are very long
barplot(results_camera$updown, 
        col = p_color, 
        names.arg=rownames(results_camera), 
        las=3,
        ylab="Down UP",
        main = "UP/DOWN tendency", 
        cex.names = 0.7)
legend("bottomleft", legend = c("P > Threshold","P < Threshold"), lty = 1, col = c("grey","#FF9999"),box.col = "transparent", cex = 0.7)
dev.off()
