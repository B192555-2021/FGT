my rshiny app requires the Limma_FC.RData

the app can generate three different plots,
all three have chooseable parameters

enjoy! thanks for using 