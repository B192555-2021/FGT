#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(pheatmap)
library(shinyjs)

#load the example data
       load("Limma_FC.RData")
       
       #turn off the RStudio graphics
       graphics.off()

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("B192555 Rshiny plot"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            #below helps to choose what ot plot
            helpText("First please choose what to plot"),
            selectInput("plot_choice",
                        "Plot choice:",
                        choices=c("Heatmap","P-value-histogram","UP/DOWN-by-Enrichment")),
            
            #parameters for heatmap
            helpText("Choices for heatmap"),  
            sliderInput("font_row",
                        "Font size row:",
                        min = 6,
                        max = 14,
                        value = 10),
            sliderInput("font_col",
                        "Font size col:",
                        min = 6,
                        max = 14,
                        value = 10),
            sliderInput("display_num",
                        "Display number:",
                        min = 10,
                        max = 200,
                        value = 50), 
            checkboxInput("srownames", "Show Row Names", FALSE),
            selectInput("select",  
                        "Select group name", 
                        choices=c("none",colnames(sample_name)),
                        selected = NULL, 
                        multiple = T,
                        selectize = TRUE),
            checkboxInput("srowclu", "Show Row Cluster", FALSE),
            sliderInput("display_rowclu",
                        "Row cluster height:",
                        min = 10,
                        max = 100,
                        value = 50), 
            checkboxInput("scolclu", "Show Column Cluster", FALSE),           
            sliderInput("display_colclu",
                        "Column cluster height:",
                        min = 10,
                        max = 100,
                        value = 50), 
            checkboxInput("logtansform", "Log transform values", FALSE),
            radioButtons("norm", "Scale by", choices=c("none","row","column")),
            
            #parameters for histogram
            helpText("Choices for histogram"),
            selectInput("hist_choice",
                        "Choice of plot:",
                        choices=c("logFC","P.Value")),
            sliderInput("bins",
                        "Number of bins:",
                        min = 1,
                        max = 50,
                        value = 30),
            
            #parameters for UP/DOWN plot
            helpText("Choices for UP/DOWN plot"),
            sliderInput("p_cut",
                        "Choose threshold of p-value:",
                        min = 0.001,
                        max = 1,
                        value = 0.05)
            
            ),
            
        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output,session) {

    output$distPlot <- renderPlot({

        #this helps to use log scale or not
        #here eset_values is already in log
        if(input$logtansform){
            expression <- eset_values[1:input$display_num,]
        }else{
            expression <- 2^eset_values[1:input$display_num,]
        }
        
        #this is to choose annoation of heatmap
        if(is.null(input$select)){
            mysel<-NULL
        }else if(input$select[1]=="none"){
            mysel<-NULL
        }else if(length(input$select)==1){
            #if the data frame has one column it converts to a factor
            #force the type to be a data frame and restore row and column names
            mysel <-as.data.frame(sample_name[,input$select[1]])
            rownames(mysel) <-colnames(expression)
            colnames(mysel) <-input$select[1]
        }else{
            mysel <-as.data.frame(sample_name[,input$select])
            rownames(mysel) <-colnames(expression)
            colnames(mysel) <-input$select
        }
        
        #plot heatmap
        if(input$plot_choice=="Heatmap"){
        
            pheatmap(expression[1:input$display_num,],
                fontsize_row=input$font_row,
                fontsize_col=input$font_col,
                show_rownames=input$srownames,
                scale=input$norm,
                annotation_col=mysel,
                cluster_cols=input$scolclu, #show col cluster or not
                treeheight_col=input$display_colclu, #cluster height
                cluster_rows=input$srowclu, #show row cluster or not
                treeheight_row=input$display_rowclu, #cluster height
                main = "Heatmap of fold change value") 
        }
        
        #plot hitogram
        if(input$plot_choice=="P-value-histogram"){
            #choose plot which column of the data
            column_of_plot <- which(colnames(allresults)==input$hist_choice)
            #set bins
            bins <- seq(min(allresults[,column_of_plot]), max(allresults[,column_of_plot]), length.out = input$bins + 1)
            breaks = bins
            #set name of xlab
            xname <- colnames(allresults)[column_of_plot]
            hist(allresults[,column_of_plot],
                 col = 'darkgray',
                 breaks = bins, 
                 border = 'white',
                 xlim = range(breaks),
                 main = "histogram",
                 xlab = xname,
                 ylab = "frequency")
        }
        
        #plot UP/DOWN-by-Enrichment plot
        if(input$plot_choice=="UP/DOWN-by-Enrichment"){
            camera_length <- length(results_camera[,1])
            #use p-value as threshold to show bars in the plot indifferent colour
            p_color <- rep("red",each=camera_length)
            for (i in 1:camera_length){
                if(results_camera[i,3] >= input$p_cut){
                    p_color[i] <- c("grey")
                }
                if(results_camera[i,3] < input$p_cut){
                    p_color[i] <- c("#FF9999") # #FF9999 is a light red color  
                }
            }
            #xlabel is very long it is helpful to set the margin
            par(mar = c(10, 2, 4, 2)+3, yaxt="n")
            barplot(results_camera$updown, 
                    col = p_color, 
                    names.arg=rownames(results_camera), 
                    las=3, 
                    main = "UP/DOWN tendency",
                    ylab="Down UP",
                    cex.names = 0.5)
            legend("bottomleft", legend = c("P > Threshold","P < Threshold"), lty = 1, col = c("grey","#FF9999"),box.col = "transparent", cex = 0.7)
            
        }
    }, execOnResize = F)
    
    observeEvent(input$refresh, {
        session$invalidate
    })
        

}

# Run the application 
shinyApp(ui = ui, server = server)
